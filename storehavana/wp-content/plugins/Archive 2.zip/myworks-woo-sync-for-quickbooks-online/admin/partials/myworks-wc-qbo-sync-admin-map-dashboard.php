﻿<?php
if ( ! defined( 'ABSPATH' ) )
exit;

?>
<?php require_once plugin_dir_path( __FILE__ ) . 'myworks-wc-qbo-sync-admin-map-nav.php' ?>
<h1 style="text-align:center;"><?php _e( 'Map Dashboard', 'mw_wc_qbo_sync' );?></h1> 
<h6 style="text-align:center;">Choose a data type in the menu bar to configure mapping data to QuickBooks Online.</h6></br></br></br></br></br></br></br></br></br></br></br>
