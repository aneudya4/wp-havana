﻿<?php
if ( ! defined( 'ABSPATH' ) )
exit;
?>

<h1 style="text-align:center;"><?php _e( 'Pull Dashboard', 'mw_wc_qbo_sync' );?></h1> 
<h6 style="text-align:center;">Choose a data type in the menu bar to begin pulling data into WooCommerce.</h6></br></br></br></br></br></br></br></br></br></br></br>
