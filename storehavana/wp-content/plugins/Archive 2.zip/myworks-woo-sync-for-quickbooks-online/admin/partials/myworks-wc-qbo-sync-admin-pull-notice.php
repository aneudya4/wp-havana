<?php
if ( ! defined( 'ABSPATH' ) )
exit;
?>

<h4><?php _e( 'Please complete your initial setup steps to access this page.', 'mw_wc_qbo_sync' );?></h4>