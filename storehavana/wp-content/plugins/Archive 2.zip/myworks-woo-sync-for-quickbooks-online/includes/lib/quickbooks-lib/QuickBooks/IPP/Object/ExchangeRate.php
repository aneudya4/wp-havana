<?php

QuickBooks_Loader::load('/QuickBooks/IPP/Object.php');

class QuickBooks_IPP_Object_ExchangeRate extends QuickBooks_IPP_Object
{
	
}
