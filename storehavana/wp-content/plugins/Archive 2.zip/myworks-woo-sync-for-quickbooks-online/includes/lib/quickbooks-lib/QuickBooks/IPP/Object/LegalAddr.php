<?php

QuickBooks_Loader::load('/QuickBooks/IPP/Object.php');

class QuickBooks_IPP_Object_LegalAddr extends QuickBooks_IPP_Object
{
	
}
