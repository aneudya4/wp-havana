<?php

QuickBooks_Loader::load('/QuickBooks/IPP/Object.php');

class QuickBooks_IPP_Object_VendorAddr extends QuickBooks_IPP_Object
{
	
}
