<?php // silence is deafening
