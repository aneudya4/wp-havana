<?php

namespace AgeGate\Admin\Settings;

trait Access
{
    protected function getAccessFields()
    {
        return [
            [],
        ];
    }
}
