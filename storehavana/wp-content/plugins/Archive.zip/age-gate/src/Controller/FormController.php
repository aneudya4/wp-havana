<?php

namespace AgeGate\Controller;

class FormController
{
    public function __construct()
    {
    }
}
