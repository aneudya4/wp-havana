import { createHooks } from '@wordpress/hooks';

global.AgeGateHooks = createHooks();
