import { fireEvent } from './utility';

window.addEventListener('DOMContentLoaded', () => {
    fireEvent('age_gate_shown');
    fireEvent('agegateshown');
});
