<div id="ag-media" class="modal">
	<div class="modal-inner">
		<a class="js-close-modal">&times;</a>
		<div class="modal-content">
            <div class="modal-media">
                <div id="ag-media-gallery"></div>
                <div class="modal-footer">
                    <button type="button" class="button js-close-modal"><?php echo esc_html(__('Cancel', 'age-gate')); ?></button>
                    <button type="button" class="button button-primary"><?php echo esc_html(__('Select', 'age-gate')); ?></button>
                </div>
            </div>
        </div>
	</div>
</div>
