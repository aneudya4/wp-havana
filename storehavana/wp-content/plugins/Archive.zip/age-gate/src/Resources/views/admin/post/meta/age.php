<div class="ag-post-metabox__item ag-post-metabox__item--age">
    <?php echo esc_html__( 'Set age to: ', 'age-gate') ?> <input type="number" name="ag_settings[age]" class="small-text" value="<?php echo esc_attr($content->getAge()) ?>" /> <button type="button" class="button ag-post-metabox__set"><?php echo esc_html__( 'Set', 'age-gate' ) ?></button>
</div>
