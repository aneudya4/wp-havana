<label class="ag-switch ag-switch--small">
    <input type="checkbox" name="ag_settings[bypass]" class="ag_settings_switch" value="1" <?php echo ($checked ? 'checked' : '') ?>  />
    <span class="ag-switch__slider"></span>
</label> <?php echo esc_html(__('Do not age restrict this content', 'age-gate')) ?>

