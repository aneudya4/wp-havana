<div class="form-field age-gate-wrap">
    <?php echo $this->section('content') ?>
</div>
