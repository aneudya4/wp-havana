<tr class="form-field term-age-gate-wrap">
	<th scope="row"><?php echo esc_html(__('Age Restriction', 'age-gate')); ?></th>
	<td>
        <?php echo $this->section('content') ?>
    </td>
</tr>
