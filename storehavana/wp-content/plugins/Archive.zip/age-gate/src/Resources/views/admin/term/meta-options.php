<?php $this->layout('term/' . $action . '-wrapper'); ?>

<?php $this->insert('post/meta-box'); ?>
