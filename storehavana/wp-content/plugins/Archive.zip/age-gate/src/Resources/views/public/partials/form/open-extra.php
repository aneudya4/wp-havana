<div <?php echo $this->attr('age-gate-extra') ?>>
