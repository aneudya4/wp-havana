<form method="post" <?php echo $this->attr('age-gate-form') ?>>
