<div <?php echo $this->attr('age-gate-submit-section') ?>>
    <button type="submit" name="ag_settings[submit]" value="1" <?php echo $this->attr('age-gate-submit') ?>><?php echo esc_html($settings->labelSubmit) ?></button>
</div>
