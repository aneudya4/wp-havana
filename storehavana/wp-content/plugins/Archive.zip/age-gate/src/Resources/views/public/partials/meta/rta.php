<meta name="rating" content="<?php echo esc_attr(apply_filters('age_gate/meta/rta', 'RTA-5042-1996-1400-1577-RTA')) ?>" />
