<div class="age-gate-shortcode-js" data-agegate="<?php echo esc_attr($restrictedContent) ?>" data-data="<?php echo esc_attr($options) ?>">
    <script type="text/template">
        <?php $this->insert('shortcode/shortcode-standard') ?>
    </script>
</div>
