<?php

namespace AgeGate\Update;

class Deactivate
{
    public static function deactivate()
    {}
}
